var searchData=
[
  ['nmffileviewer',['nmfFileViewer',['../classnmf_file_viewer.html#a04246e2e514bd3e6778ab9923fc81983',1,'nmfFileViewer']]],
  ['nmflogger',['nmfLogger',['../classnmf_logger.html#a3ca5a992a3e28751e1555beafb7ed13e',1,'nmfLogger']]]
];
