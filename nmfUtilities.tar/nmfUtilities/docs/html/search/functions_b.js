var searchData=
[
  ['removesettingsfile',['removeSettingsFile',['../namespacenmf_utils_qt.html#a741f31eeae5a15f711cb728beafb509b',1,'nmfUtilsQt']]],
  ['rename',['rename',['../namespacenmf_utils_qt.html#a4326678543b25866ed2fdfe6fe87a051',1,'nmfUtilsQt']]]
];
