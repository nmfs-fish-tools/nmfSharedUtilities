var searchData=
[
  ['linregout',['LinRegOut',['../struct_lin_reg_out.html',1,'']]],
  ['logmsg',['logMsg',['../classnmf_logger.html#a0e607badf8844edfa4663bc68e8c69b9',1,'nmfLogger']]]
];
