var searchData=
[
  ['getcurrenttabname',['getCurrentTabName',['../namespacenmf_utils_qt.html#aea1c506cd62ccf21a0d8dc3c8e5e1cf6',1,'nmfUtilsQt']]],
  ['getfilename',['getFilename',['../classnmf_structs_qt_1_1_chart_save_dlg.html#a1cc6d5263b4ef8935147491c62aaee76',1,'nmfStructsQt::ChartSaveDlg']]],
  ['getlogfile',['getLogFile',['../classnmf_logger.html#a485e96de3c87c13cd5fe5f7814ef0c14',1,'nmfLogger']]],
  ['gettabindex',['getTabIndex',['../namespacenmf_utils_qt.html#a0c838cb5b372e4f06d76faa0cd0cfbb0',1,'nmfUtilsQt']]],
  ['gettimestamp',['getTimestamp',['../classnmf_logger.html#a20c73cd1d0c1005fd44c549286d52337',1,'nmfLogger']]]
];
